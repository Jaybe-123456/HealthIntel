'use strict';

/** @type {import('./range')} */
module.exports = RangeError;
