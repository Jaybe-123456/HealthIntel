declare function isPromise<T, S>(obj: PromiseLike<T> | S): obj is PromiseLike<T>;
export default isPromise;
