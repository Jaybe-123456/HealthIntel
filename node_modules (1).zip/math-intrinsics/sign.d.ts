declare function sign(x: number): number;

export = sign;